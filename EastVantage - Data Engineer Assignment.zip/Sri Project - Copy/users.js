const { v4: uuidv4 } = require('uuid');

class User {
    constructor(username, age, hobbies = []) {
        this.id = uuidv4(); // Generate a unique identifier
        this.username = username;
        this.age = age;
        this.hobbies = hobbies;
    }
}

// Define an array to store user objects
const users = [];

// Function to add a new user to the users array
function addUser(username, age, hobbies = []) {
    const newUser = new User(username, age, hobbies);
    users.push(newUser);
    return newUser;
}

// Add some users to the array
addUser('Alice', 30, ['reading', 'gardening']);
addUser('Bob', 25, ['hiking']);
addUser('Charlie', 35, ['chess playing']);

module.exports = users;


